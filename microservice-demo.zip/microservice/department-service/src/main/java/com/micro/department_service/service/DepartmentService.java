package com.micro.department_service.service;

import com.micro.department_service.model.Department;

public interface DepartmentService {
    Department saveDepartment(Department department);

    Department getDepartmentById(Long departmentId);
}
