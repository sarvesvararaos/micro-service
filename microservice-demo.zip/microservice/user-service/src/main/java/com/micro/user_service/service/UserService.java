package com.micro.user_service.service;

import com.micro.user_service.dto.ResponseDto;
import com.micro.user_service.model.User;

public interface UserService {
    User saveUser(User user);

    ResponseDto getUser(Long userId);
}
